package com.wyyu.debug_annotate;

/**
 * Created by wyyu on 2019-09-26.
 **/

public interface IDebugAnnotate {

    String getValue(Class<?> keyClass);
}
